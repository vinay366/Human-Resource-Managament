﻿using System.ComponentModel.DataAnnotations;

namespace HRMCodeFirstApproch.Dtos
{
    public class PersonDtos
    {

        [Required]
        [StringLength(50)]
        public string PersonName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string PersonEmail { get; set; } = string.Empty;

        [Required]
        [MinLength(6), MaxLength(8)]
        public string PersonPassword { get; set; } = string.Empty;

        [Required]
        [Compare("PersonPassword", ErrorMessage = "Password and Confirm Password must match")]
        public string PersonConfirmPassword { get; set; } = string.Empty;

        public DateOnly PersonCreated { get; set; }
    }

}
