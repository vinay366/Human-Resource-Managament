﻿using HRMCodeFirstApproch.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRMCodeFirstApproch.Dtos
{
    public class EmployeeDtos
    {

        public Guid EmployeeID { get; set; }

       
        public DateOnly? EmployeeJoining { get; set; }

        public string? EmployeeDesignation { get; set; } = string.Empty;

        public string? EmployeeDepartment { get; set; } = string.Empty;

        public DateOnly? EmployeeResigning { get; set; }

        public DateOnly? EmployeeTermination { get; set; }

        public string? EmployeeSalary { get; set; }

        public string? EmployeeStatus { get; set; } = string.Empty;

        public DateOnly EmployeeCreated { get; set; }
        public Guid CandidateID { get; set; }

        public string PersonName { get; set; } = string.Empty;

        public Person Persons { get; set; } = new Person();
    }
}
