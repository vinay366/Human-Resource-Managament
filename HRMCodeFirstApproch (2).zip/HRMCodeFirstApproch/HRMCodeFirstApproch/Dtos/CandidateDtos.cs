﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRMCodeFirstApproch.Dtos
{
    public class CandidateDtos
    {
        public int CandidateAge { get; set; }

        public string CandidateGender { get; set; } = string.Empty;

        public string CandidateAddress { get; set; } = string.Empty;

        public long CandidateContact { get; set; }

        public long CandidateAadhar { get; set; }

        public string CandidatePan { get; set; } = string.Empty;

        public DateOnly CandidateDOB { get; set; }

        public string CandidateQualification { get; set; } = string.Empty;

        public DateOnly CandidateCreated { get; set; }

        public Guid PersonID { get; set; }
        public string PersonName { get; set; } = string.Empty;
    }
}
