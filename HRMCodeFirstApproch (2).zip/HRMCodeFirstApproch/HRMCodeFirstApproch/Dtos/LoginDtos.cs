﻿using System.ComponentModel.DataAnnotations;

namespace HRMCodeFirstApproch.Dtos
{
    public class LoginDtos
    {
        public Guid PersonID { get; set; }
        public string PersonEmail { get; set; } = string.Empty;
        public string PersonPassword { get; set; } = string.Empty;
    }
}
