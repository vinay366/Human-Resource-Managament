﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRMCodeFirstApproch.Models
{
    public class Candidate 
    {
        [Key]
        public Guid CandidateID { get; set; }

        [Required(ErrorMessage = "Age is required")]
        [Range(18, 60, ErrorMessage = "Age must be between 18 and 60 years")]
        public int CandidateAge { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        [RegularExpression("^(Male|Female|Other)$", ErrorMessage = "Please enter Male, Female, or Other")]
        public string CandidateGender { get; set; } = string.Empty;

        [Required(ErrorMessage = "Address is required")]
        [StringLength(200, MinimumLength = 10, ErrorMessage = "Address must be between 10 and 200 characters")]
        public string CandidateAddress { get; set; } = string.Empty;
        [Required(ErrorMessage = "Contact number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Please enter a valid 10-digit contact number")]
        public long CandidateContact { get; set; }

        [Required(ErrorMessage = "Aadhar number is required")]
        [RegularExpression(@"^\d{12}$", ErrorMessage = "Please enter a valid 12-digit Aadhar number")]
        public long CandidateAadhar { get; set; }

        [Required(ErrorMessage = "PAN number is required")]
        [RegularExpression(@"^[A-Z]{5}[0-9]{4}[A-Z]{1}$", ErrorMessage = "Please enter a valid PAN number")]
        public string CandidatePan { get; set; } = string.Empty;

        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        [Range(18,60, ErrorMessage = "You must be at least 18 years old")]
        public DateOnly CandidateDOB { get; set; }

        [Required(ErrorMessage = "Qualification is required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Qualification must be between 2 and 100 characters")]
        public string CandidateQualification { get; set; } = string.Empty;

        public DateOnly CandidateCreated { get; set; }

        [ForeignKey("PersonID")]

        public Guid PersonID { get; set; }



    }
}
