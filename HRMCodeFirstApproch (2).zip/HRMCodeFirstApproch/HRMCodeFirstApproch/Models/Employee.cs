﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRMCodeFirstApproch.Models
{
    public class Employee
    {
        [Key]

        public Guid EmployeeID { get; set; }

        public DateOnly? EmployeeJoining { get; set; }

        public string? EmployeeDesignation { get; set; } = string.Empty;

        public string? EmployeeDepartment { get; set; } = string.Empty;

        public DateOnly? EmployeeResigning { get; set; }

        public DateOnly? EmployeeTermination { get; set; }

        public string? EmployeeSalary { get; set; }

        public string? EmployeeStatus { get; set; } = string.Empty;

        public DateOnly EmployeeCreated { get; set; }

        [ForeignKey("CandidateID")]

        public Guid CandidateID { get; set; }
    }
}
