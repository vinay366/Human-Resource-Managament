﻿using HRMCodeFirstApproch.Dtos;
using HRMCodeFirstApproch.HRMContext;
using HRMCodeFirstApproch.Models;
using Microsoft.EntityFrameworkCore;

namespace HRMCodeFirstApproch.Service
{
    public class PersonService
    {
        private readonly HRMDbContext _context;

        public PersonService(HRMDbContext hRMDbContext)
        {
            _context = hRMDbContext;
        }

        public async Task<Person> PostPerson(PersonDtos person)
        {
            Person p = new Person
            {
                PersonID = Guid.NewGuid(),
                PersonName = person.PersonName,
                PersonEmail = person.PersonEmail,
                PersonPassword = person.PersonPassword,
                PersonConfirmPassword = person.PersonConfirmPassword,
                PersonCreated = DateOnly.FromDateTime(DateTime.Now)
            };
            var res= await  _context.Persons.AddAsync(p);
            await _context.SaveChangesAsync();
            return res.Entity;
        }

        public async Task<Person> LoginPerson(LoginDtos loginDtos)
        {
            var res = await _context.Persons.FirstOrDefaultAsync(x => x.PersonEmail == loginDtos.PersonEmail && x.PersonPassword == loginDtos.PersonPassword);
            return res;
        }

        
        public async Task<Person> GetPersonEmail(string email)
        {
            return await _context.Persons.FirstOrDefaultAsync(x => x.PersonEmail == email);
        }

        public async Task<bool> CandidateExists(Guid personId)
        {
            // Query your database to check if the person is already a candidate
            var candidate = await _context.Candidates
                .FirstOrDefaultAsync(c => c.PersonID == personId); // Assuming PersonId is a foreign key

            return candidate != null; // Return true if the candidate exists
        }
        public async Task<bool> EmployeeExists(Guid CandidateID)
        {
            // Query your database to check if the person is already a candidate
            var candidate = await _context.Employees
                .FirstOrDefaultAsync(c => c.CandidateID == CandidateID); // Assuming PersonId is a foreign key

            return candidate != null; // Return true if the candidate exists
        }
    }
}
