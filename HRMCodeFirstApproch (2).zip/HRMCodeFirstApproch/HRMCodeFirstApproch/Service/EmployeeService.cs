﻿using HRMCodeFirstApproch.Dtos;
using HRMCodeFirstApproch.HRMContext;
using HRMCodeFirstApproch.Models;
using Microsoft.EntityFrameworkCore;

namespace HRMCodeFirstApproch.Service
{
    public class EmployeeService
    {
        private readonly HRMDbContext _context;

        public EmployeeService(HRMDbContext hRMDbContext)
        {
            _context = hRMDbContext;
        }

        /*public async Task<Employee> PostEmployee(EmployeeDtos employee)
        {
            
            Employee e = new Employee
            {
                EmployeeID = Guid.NewGuid(),
                EmployeeJoining = employee.EmployeeJoining,
                EmployeeDepartment = employee.EmployeeDepartment,
                EmployeeDesignation = employee.EmployeeDesignation,
                EmployeeResigning = employee.EmployeeResigning,
                EmployeeTermination = employee.EmployeeTermination,
                EmployeeSalary = employee.EmployeeSalary,
                EmployeeStatus = employee.EmployeeStatus,
                CandidateID = candidate.CandidateID,
                EmployeeCreated = DateOnly.FromDateTime(DateTime.Now)
            };
            var res = await _context.Employees.AddAsync(e);
            await _context.SaveChangesAsync();
            return res.Entity;
        }*/

        public async Task<Employee> PostEmployee(EmployeeDtos employee)
        {
            // Validate CandidateID
            if (employee.CandidateID == Guid.Empty)
            {
                throw new ArgumentException("CandidateID is required.");
            }

            // Check if Candidate exists
            var candidate = await _context.Candidates.FindAsync(employee.CandidateID);
            if (candidate == null)
            {
                throw new Exception("CandidateID does not exist. Please provide a valid CandidateID.");
            }

            // Create Employee entity
            Employee e = new Employee
            {
                EmployeeID = Guid.NewGuid(),
                EmployeeJoining = employee.EmployeeJoining,
                EmployeeDepartment = employee.EmployeeDepartment,
                EmployeeDesignation = employee.EmployeeDesignation,
                EmployeeResigning = employee.EmployeeResigning,
                EmployeeTermination = employee.EmployeeTermination,
                EmployeeSalary = employee.EmployeeSalary,
                EmployeeStatus = employee.EmployeeStatus,
                CandidateID = candidate.CandidateID, // Link the CandidateID
                EmployeeCreated = DateOnly.FromDateTime(DateTime.Now)
            };

            // Add Employee to the database
            var res = await _context.Employees.AddAsync(e);
            await _context.SaveChangesAsync();

            return res.Entity;
        }



        public async Task<Employee> GetCandidate(Guid CandidateID)
        {
            return await _context.Employees.FirstOrDefaultAsync(x => x.CandidateID == CandidateID);
        }

        public async Task<List<Employee>> GetAllEmployee()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<Employee> GetEmployeeByPersonId(Guid personId)
        {
            var candidate = await _context.Candidates
           .FirstOrDefaultAsync(c => c.PersonID == personId);

            if (candidate == null)
            {
                return null;
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.CandidateID == candidate.CandidateID);

            return employee;
        }
    }


}

