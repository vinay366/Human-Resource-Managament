﻿using HRMCodeFirstApproch.Dtos;
using HRMCodeFirstApproch.HRMContext;
using HRMCodeFirstApproch.Models;
using Microsoft.EntityFrameworkCore;

namespace HRMCodeFirstApproch.Service
{
    public class CandidateService
    {
        private readonly HRMDbContext _context;
        public CandidateService(HRMDbContext hRMDbContext)
        {
            _context = hRMDbContext;
        }
        public async Task<Candidate> PostCandidate(CandidateDtos candidate, Person person)
        {
            Candidate c = new Candidate
            {
                CandidateID = Guid.NewGuid(),
                CandidateAadhar = candidate.CandidateAadhar,
                CandidateAddress = candidate.CandidateAddress,
                CandidateAge = candidate.CandidateAge,
                CandidateContact = candidate.CandidateContact,
                CandidateDOB = candidate.CandidateDOB,
                CandidateGender = candidate.CandidateGender,
                CandidatePan = candidate.CandidatePan,
                CandidateQualification = candidate.CandidateQualification,
                PersonID = person.PersonID,
                CandidateCreated = DateOnly.FromDateTime(DateTime.Now)
            };
            var res = await _context.Candidates.AddAsync(c);
            await _context.SaveChangesAsync();

            Employee e = new Employee()
            {
                EmployeeID = Guid.NewGuid(),
                CandidateID = c.CandidateID,
                EmployeeCreated = DateOnly.FromDateTime(DateTime.Now),
            };

            var resultEmployee = await _context.Employees.AddAsync(e);
            await _context.SaveChangesAsync();
            return res.Entity;
        }

       

        



    }
}
