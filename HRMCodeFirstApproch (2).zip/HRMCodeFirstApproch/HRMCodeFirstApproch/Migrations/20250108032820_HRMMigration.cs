﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HRMCodeFirstApproch.Migrations
{
    /// <inheritdoc />
    public partial class HRMMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Candidates",
                columns: table => new
                {
                    CandidateID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CandidateAge = table.Column<int>(type: "int", nullable: false),
                    CandidateGender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CandidateAddress = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CandidateContact = table.Column<long>(type: "bigint", nullable: false),
                    CandidateAadhar = table.Column<long>(type: "bigint", nullable: false),
                    CandidatePan = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CandidateDOB = table.Column<DateOnly>(type: "date", nullable: false),
                    CandidateQualification = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CandidateCreated = table.Column<DateOnly>(type: "date", nullable: false),
                    PersonID = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Candidates", x => x.CandidateID);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    EmployeeID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EmployeeJoining = table.Column<DateOnly>(type: "date", nullable: true),
                    EmployeeDesignation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmployeeDepartment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmployeeResigning = table.Column<DateOnly>(type: "date", nullable: true),
                    EmployeeTermination = table.Column<DateOnly>(type: "date", nullable: true),
                    EmployeeSalary = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmployeeStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmployeeCreated = table.Column<DateOnly>(type: "date", nullable: false),
                    CandidateID = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.EmployeeID);
                });

            migrationBuilder.CreateTable(
                name: "Persons",
                columns: table => new
                {
                    PersonID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PersonName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PersonEmail = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PersonPassword = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    PersonConfirmPassword = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PersonCreated = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Persons", x => x.PersonID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Candidates_CandidateAadhar",
                table: "Candidates",
                column: "CandidateAadhar",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Candidates_CandidateContact",
                table: "Candidates",
                column: "CandidateContact",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Candidates_CandidatePan",
                table: "Candidates",
                column: "CandidatePan",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Persons_PersonEmail",
                table: "Persons",
                column: "PersonEmail",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Candidates");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "Persons");
        }
    }
}
