﻿using HRMCodeFirstApproch.Dtos;
using HRMCodeFirstApproch.HRMContext;
using HRMCodeFirstApproch.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HRMCodeFirstApproch.Controllers
{
    

    
    public class AdminController : Controller
    {
        private readonly HRMDbContext _context;

        public AdminController(HRMDbContext hRMDbContext)
        {
            _context = hRMDbContext;
        }

        [HttpGet]
        public IActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AdminLogin(AdminDtos adminDtos)
        {
            // Replace with your actual admin credentials check
            if (adminDtos.Username == "admin" && adminDtos.Password == "admin123")
            {
                // Set session or authentication cookie
                TempData["AdminLoggedIn"] = true;
                return RedirectToAction("AdminDashboard");
            }

            ModelState.AddModelError("", "Invalid username or password");
            return View(adminDtos); // Return to login view with error
        }

        [HttpGet]
        public async Task<IActionResult> AdminDashboard()
        {
            var res = await _context.Employees.ToListAsync();

            return View(res);
        }
        [HttpPost]
        public async Task<IActionResult> Terminate(Guid id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                employee.EmployeeStatus = "Terminated"; // Update status to terminated
                employee.EmployeeTermination = DateOnly.FromDateTime(DateTime.Now); // Set termination date
                await _context.SaveChangesAsync();
            }

            return RedirectToAction("AdminDashboard");
        }

        [HttpGet] 
        public async Task<IActionResult> GetPerson(Person person)
        {
            return View(await _context.Persons.ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> GetCandidate(Candidate candidate)
        {
            return View(await _context.Candidates.ToListAsync());
        }

    }
}
