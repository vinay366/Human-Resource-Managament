﻿using HRMCodeFirstApproch.Dtos;
using HRMCodeFirstApproch.HRMContext;
using HRMCodeFirstApproch.Models;
using HRMCodeFirstApproch.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HRMCodeFirstApproch.Controllers
{
    public class PersonController : Controller
    {
        private readonly PersonService _personService;
        private readonly CandidateService _candidateService;
        private readonly EmployeeService _employeeservice;
        private readonly HRMDbContext _context;

        public PersonController(PersonService personService,CandidateService candidateService,EmployeeService employeeService ,HRMDbContext hRMDbContext)
        {
            _personService = personService;
            _candidateService = candidateService;
            _employeeservice = employeeService;
            _context = hRMDbContext;
        }
        [HttpGet]
        public IActionResult Index()
        {
            ViewData["ShowGetStartedButton"] = "false";
            return View();
        }
        [HttpPost]
        public async  Task<IActionResult> Index(PersonDtos person)
        {
            await _personService.PostPerson(person);
            // TempData["PersonName"] = person.PersonName;
            HttpContext.Session.SetString("PersonName", person.PersonName);
            return RedirectToAction("Index","Home");

        }
        [HttpGet]

        public IActionResult Login()
        {
            ViewData["ShowGetStartedButton"] = "false";

            /*if (TempData.Peek("PersonName") != null)
            {
                TempData.Keep("PersonName");
            }*/

            ViewBag.PersonName = HttpContext.Session.GetString("PersonName");
            return View();
        }
        /*[HttpPost]
        public async Task<IActionResult> Login(LoginDtos loginDtos)
        {
            var res = await _personService.LoginPerson(loginDtos);
            TempData["Login"] = JsonSerializer.Serialize(res);

            if (res != null)
            {
                bool candidateExists = await _personService.CandidateExists(res.PersonID); // Assume this service method checks if a candidate exists

                if (candidateExists)
                {
                    
                    return RedirectToAction("EmployeeDashBorad");
                }
                else
                {
                    // Redirect to Candidate page
                    return RedirectToAction("Candidate");
                }


            }
            
            return RedirectToAction("Login");
         }*/

        [HttpPost]
        public async Task<IActionResult> Login(LoginDtos loginDtos)
        {
            var res = await _personService.LoginPerson(loginDtos);
            TempData["Login"] = JsonSerializer.Serialize(res);
/*
            if (TempData.Peek("PersonName") != null)
            {
                TempData.Keep("PersonName");
            }
*/
            if (res != null)
            {
                // First check if person is a candidate
                bool candidateExists = await _personService.CandidateExists(res.PersonID);

                if (candidateExists)
                {
                    // Get the candidate's ID to check employee status
                    var candidate = await _context.Candidates
                        .FirstOrDefaultAsync(c => c.PersonID == res.PersonID);

                    if (candidate != null)
                    {
                        // Check if they are an employee using CandidateID
                        bool employeeExists = await _personService.EmployeeExists(candidate.CandidateID);

                        if (employeeExists)
                        {
                            // If they are both a candidate and employee, redirect to  dashboard
                            return RedirectToAction("Dashboard"); 
                        }
                    }

                    // If they are only a candidate, redirect to EmployeeDashBorad page
                    return RedirectToAction("EmployeeDashBorad");
                }
                else
                {
                    // If they are not a candidate, redirect to candidate page
                    return RedirectToAction("Candidate");
                }
            }

            // If login failed, redirect back to login page
            return RedirectToAction("Index","Home");
        }



        [HttpGet]
        public IActionResult Candidate()

        {
            ViewBag.PersonName = HttpContext.Session.GetString("PersonName");
            return View();
        }
        /*[HttpPost]
        public async Task<IActionResult> Candidate(CandidateDtos candidate)
        {
            

            var personId = TempData.Peek("Login") as string;
           
            var data = JsonSerializer.Deserialize<Person>(personId);

            
            if (data != null)
            {

                await _candidateService.PostCandidate(candidate, data);
                return RedirectToAction("EmployeeDashBorad");
            }
            return RedirectToAction("Login");


        }*/
        [HttpPost]
        public async Task<IActionResult> Candidate(CandidateDtos candidate)
        {
            var personId = TempData.Peek("Login") as string;

            if (string.IsNullOrEmpty(personId))
            {
                // Redirect to login if personId is not available
                return RedirectToAction("Index");
            }

            var data = JsonSerializer.Deserialize<Person>(personId);

            if (data != null)
            {
                var result = await _candidateService.PostCandidate(candidate, data);

                if (result != null)
                {
                    // Store CandidateID in TempData
                    TempData["CandidateID"] = JsonSerializer.Serialize(result.CandidateID);
                    return RedirectToAction("EmployeeDashBorad"); // Fixed typo in method name
                }
                else
                {
                    ModelState.AddModelError("", "Failed to create candidate. Please try again.");
                }
            }
            else
            {
                ModelState.AddModelError("", "Invalid person data. Please log in again.");
            }

            // If we reach here, something went wrong; return to the view with errors
            return View(candidate); // Return the same view with the candidate model for corrections
        }

        [HttpGet]
        public async Task <IActionResult> Dashboard()
        {

            var loginJson = TempData["Login"]?.ToString();

            /* if (TempData.Peek("PersonName") != null)
             {
                 TempData.Keep("PersonName");
             }*/
            ViewBag.PersonName = HttpContext.Session.GetString("PersonName");
            if (loginJson != null)
            {
                var loginInfo = JsonSerializer.Deserialize<LoginDtos>(loginJson);
                var employee = await _employeeservice.GetEmployeeByPersonId(loginInfo.PersonID);

                if (employee != null)
                {
                   // ViewBag.PersonName = TempData["PersonName"]; 
                    return View(employee);
                }
            }

            return RedirectToAction("Login");
        }

        
        [HttpGet]
        public JsonResult GetDepartments()
        {
            var departments = new List<string> {
            "IT", "HR", "Finance", "Marketing", "Operations"
        };
            return Json(departments);
        }

        [HttpGet]
        public JsonResult GetDesignations(string department)
        {
            var designations = new Dictionary<string, List<string>>
            {
                ["IT"] = new List<string> { "Software Engineer", "DevOps Engineer", "QA Engineer" },
                ["HR"] = new List<string> { "HR Manager", "Recruiter", "HR Executive" },
                ["Finance"] = new List<string> { "Accountant", "Financial Analyst", "Controller" }
                // Add more as needed
            };

            return Json(designations.GetValueOrDefault(department, new List<string>()));
        }

        [HttpGet]
        public JsonResult GetSalaryRanges()
        {
            var salaryRanges = new List<string> {
            "2LPA - 4LPA",
            "4LPA - 6LPA",
            "6LPA - 8LPA",
            "8LPA - 10LPA"
        };
            return Json(salaryRanges);
        }
        /*  [HttpPost]
          public async Task<IActionResult> Accept(EmployeeDtos employee)
          {

              var result = await _employeeservice.PostEmployee(employee);
              return RedirectToAction("Dashboard");
          }*/




        [HttpPost]
        public async Task<IActionResult> Accept(EmployeeDtos employee)
        {
            // Retrieve CandidateID from TempData
            var candidateIdJson = TempData.Peek("CandidateID") as string;

            if (!string.IsNullOrEmpty(candidateIdJson))
            {
                try
                {
                    // Attach the CandidateID to the employee object
                    employee.CandidateID = JsonSerializer.Deserialize<Guid>(candidateIdJson);

                    // Call service to process the employee data
                    var result = await _employeeservice.PostEmployee(employee);

                    if (result != null)
                    {
                        TempData["SuccessMessage"] = "Employee details submitted successfully.";
                        return RedirectToAction("Dashboard"); // Redirect to the dashboard or another page
                    }
                    else
                    {
                        ModelState.AddModelError("", "Failed to process employee details. Please try again.");
                    }
                }
                catch (JsonException ex)
                {
                    // Handle JSON deserialization errors
                    ModelState.AddModelError("", "Invalid CandidateID format.");
                }
                catch (FormatException ex)
                {
                    // Handle format exceptions specifically for GUID parsing
                    ModelState.AddModelError("", "Invalid CandidateID format.");
                }
            }
            else
            {
                // CandidateID is missing from TempData
                ModelState.AddModelError("", "CandidateID is missing. Please complete the candidate registration process.");
                TempData["ErrorMessage"] = "CandidateID is missing. Please complete the candidate registration process.";
            }

            // Reload the Employee Management view with validation errors
            return View("Candidate", employee); // Return the same view with the employee model for corrections
        }


        [HttpGet]
        public IActionResult EmployeeDashBorad()
        {
            // ViewBag.PersonName = TempData["PersonName"];

            ViewBag.PersonName = HttpContext.Session.GetString("PersonName");

            return View();
        }
      

        [HttpGet]
        public IActionResult GetEmployeeDetails(Guid Candidate) 
        { 
            if(string.IsNullOrEmpty(Candidate.ToString()))
            {
                return Json(null);
            }
            var emp= _context.Employees.FirstOrDefault(x => x.CandidateID == Candidate);
            if (emp != null)
            {
                return Json(emp);
            }
            var employeeDtos = new EmployeeDtos
            {
                EmployeeDepartment = emp.EmployeeDepartment,
                EmployeeDesignation = emp.EmployeeDesignation,
                EmployeeSalary = emp.EmployeeSalary,
                EmployeeStatus = emp.EmployeeStatus
            };
            return Json(employeeDtos);
        }



        [HttpPost]
        public async Task<IActionResult> Resign(Guid id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                employee.EmployeeStatus = "Resign"; // Update status to inactive
                employee.EmployeeResigning = DateOnly.FromDateTime(DateTime.Now); // Set resignation date
                await _context.SaveChangesAsync();
            }

            return RedirectToAction("Dashboard");
        }

        



    }


}
