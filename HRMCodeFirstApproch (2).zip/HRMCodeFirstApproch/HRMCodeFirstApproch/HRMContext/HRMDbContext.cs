﻿using HRMCodeFirstApproch.Models;
using Microsoft.EntityFrameworkCore;

namespace HRMCodeFirstApproch.HRMContext
{
    public class HRMDbContext : DbContext
    {
        public HRMDbContext(DbContextOptions<HRMDbContext> dbContextOptions): base(dbContextOptions) 
        {

        }

        public DbSet<Person> Persons { get; set; }

        public DbSet<Candidate> Candidates { get; set; }

        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Person>()
                .HasIndex(p => p.PersonEmail)
                .IsUnique();
            modelBuilder.Entity<Candidate>()
                .HasIndex(c => c.CandidateAadhar)
                .IsUnique();
            modelBuilder.Entity<Candidate>()
                .HasIndex(c => c.CandidatePan)
                .IsUnique();
            modelBuilder.Entity<Candidate>()
                .HasIndex(c => c.CandidateContact)
                .IsUnique();
        }
    }
}
